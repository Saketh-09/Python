inp=float(input('Enter the number to which you want to find its square: '))
print(inp**2)